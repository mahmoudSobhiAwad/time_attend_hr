package com.example.time_attend_hr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
